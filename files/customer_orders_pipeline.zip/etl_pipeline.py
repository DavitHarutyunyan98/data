import pandas as pd
import psycopg2
from psycopg2 import sql

# Database connection details
DB_HOST = "localhost"
DB_NAME = "etl_demo"
DB_USER = "user"
DB_PASS = "password"


def extract(file_path):
    """Extract data from CSV."""
    print("Extracting data...")
    data = pd.read_csv(file_path)
    return data


def transform(data):
    """Transform data by cleaning it."""
    print("Transforming data...")
    data['total_price'] = data['quantity'] * data['unit_price']
    data.dropna(inplace=True)
    return data


def load(data, table_name):
    """Load data into PostgreSQL."""
    print("Loading data...")
    try:
        conn = psycopg2.connect(
            host=DB_HOST, database=DB_NAME, user=DB_USER, password=DB_PASS
        )
        cursor = conn.cursor()

        # Insert data row by row
        for index, row in data.iterrows():
            cursor.execute(
                sql.SQL(
                    f"INSERT INTO {table_name} (order_id, product_name, quantity, unit_price, total_price) VALUES (%s, %s, %s, %s, %s)"),
                tuple(row)
            )
        conn.commit()
        cursor.close()
        conn.close()
    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    # File path
    csv_file_path = "data/orders.csv"
    table_name = "customer_orders"

    # ETL Process
    extracted_data = extract(csv_file_path)
    transformed_data = transform(extracted_data)
    load(transformed_data, table_name)
    print("ETL process completed!")
