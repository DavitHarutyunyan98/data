CREATE DATABASE etl_demo;

\c etl_demo;

CREATE TABLE customer_orders (
    order_id INT PRIMARY KEY,
    product_name VARCHAR(255),
    quantity INT,
    unit_price FLOAT,
    total_price FLOAT
);
